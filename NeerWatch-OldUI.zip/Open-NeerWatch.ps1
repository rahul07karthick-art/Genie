$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot

$probe = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 0)
$probe.Start()
$port = $probe.LocalEndpoint.Port
$probe.Stop()

$env:PORT = [string]$port
$stdout = Join-Path $root 'server.out.log'
$stderr = Join-Path $root 'server.err.log'
$server = Start-Process -FilePath 'node.exe' `
  -ArgumentList 'backend/server.mjs' `
  -WorkingDirectory $root `
  -RedirectStandardOutput $stdout `
  -RedirectStandardError $stderr `
  -WindowStyle Hidden `
  -PassThru

$url = "http://127.0.0.1:$port/"
$ready = $false
for ($attempt = 0; $attempt -lt 30; $attempt++) {
  Start-Sleep -Milliseconds 400
  try {
    $health = Invoke-WebRequest -Uri "http://127.0.0.1:$port/health" -TimeoutSec 2
    if ($health.StatusCode -eq 200) { $ready = $true; break }
  } catch {
    if ($server.HasExited) { break }
  }
}

if (-not $ready) {
  Write-Host 'NeerWatch did not start. See server.err.log for details.' -ForegroundColor Red
  if (Test-Path $stderr) { Get-Content $stderr }
  exit 1
}

Write-Host "NeerWatch is running at $url" -ForegroundColor Green
Start-Process $url
